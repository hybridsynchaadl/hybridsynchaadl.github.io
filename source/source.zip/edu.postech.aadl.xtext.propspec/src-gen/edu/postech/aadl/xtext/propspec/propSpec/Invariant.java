/**
 */
package edu.postech.aadl.xtext.propspec.propSpec;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Invariant</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see edu.postech.aadl.xtext.propspec.propSpec.PropSpecPackage#getInvariant()
 * @model
 * @generated
 */
public interface Invariant extends Property
{
} // Invariant
