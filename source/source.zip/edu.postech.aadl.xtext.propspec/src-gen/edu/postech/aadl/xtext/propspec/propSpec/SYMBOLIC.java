/**
 */
package edu.postech.aadl.xtext.propspec.propSpec;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SYMBOLIC</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see edu.postech.aadl.xtext.propspec.propSpec.PropSpecPackage#getSYMBOLIC()
 * @model
 * @generated
 */
public interface SYMBOLIC extends Mode
{
} // SYMBOLIC
