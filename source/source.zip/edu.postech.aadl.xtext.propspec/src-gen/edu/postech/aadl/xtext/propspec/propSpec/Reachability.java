/**
 */
package edu.postech.aadl.xtext.propspec.propSpec;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Reachability</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see edu.postech.aadl.xtext.propspec.propSpec.PropSpecPackage#getReachability()
 * @model
 * @generated
 */
public interface Reachability extends Property
{
} // Reachability
