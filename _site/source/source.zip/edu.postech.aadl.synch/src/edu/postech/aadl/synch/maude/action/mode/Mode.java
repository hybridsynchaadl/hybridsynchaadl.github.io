package edu.postech.aadl.synch.maude.action.mode;

public interface Mode {
	public String getName();
}

