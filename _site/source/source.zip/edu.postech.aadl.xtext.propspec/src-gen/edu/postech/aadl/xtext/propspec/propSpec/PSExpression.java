/**
 */
package edu.postech.aadl.xtext.propspec.propSpec;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>PS Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see edu.postech.aadl.xtext.propspec.propSpec.PropSpecPackage#getPSExpression()
 * @model
 * @generated
 */
public interface PSExpression extends EObject
{
} // PSExpression
